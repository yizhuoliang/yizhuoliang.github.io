"""One expert's block-scaled GEMM. Both traversals use identical SM100 math and epilogue."""
import json,os,random
from pathlib import Path
import torch
import deep_gemm as dg
from telemetry import measure

out=Path(os.environ['OUT'])/'single.jsonl'
torch.cuda.set_device(0)
def operand(rows,k,expert=False,fp4=False):
    # Fill finite, signed FP8 values; use exact unit scales in prepacked MN-major layout.
    a=torch.empty((rows,k//2 if fp4 else k),device='cuda',dtype=torch.int8 if fp4 else torch.float8_e4m3fn)
    step=max(1,min(rows,8*1024*1024//k))
    for start in range(0,rows,step):
        part=a[start:start+step]
        if fp4:
            part.random_(-128,128)  # Two finite E2M1 samples per byte.
        else:
            part.copy_(torch.randn(part.shape,device='cuda',dtype=torch.bfloat16))
    sf=torch.empty_strided((rows,k//128),(1,rows),device='cuda',dtype=torch.int32)
    sf.fill_(0x7f7f7f7f)
    if expert:return a.unsqueeze(0),sf.as_strided((1,rows,k//128),(sf.numel(),1,rows))
    return a,sf

def prepare(m,n,k,fp4=False,weight_fp4=False):
    torch.manual_seed((m+n+k)//256)
    a=operand(m,k,fp4=fp4);b=operand(n,k,True,fp4=fp4 or weight_fp4)
    labels=torch.zeros(m,device='cuda',dtype=torch.int32)
    y=torch.empty(m,n,device='cuda',dtype=torch.bfloat16)
    graphs={}
    for mode,order in [('stock',0),('row',1),('column',2)]:
        os.environ['CROSSOVER_GEMM_ORDER']=str(order)
        def call():
            dg.m_grouped_fp8_fp4_gemm_nt_contiguous(a,b,y,labels,recipe=(1,1,32),disable_ue8m0_cast=True,compiled_dims='')
        call();torch.cuda.synchronize()
        if mode=='stock':
            ref=y.clone()
            # Check an independent submatrix throughout the output. All scales are 1.
            mi=torch.linspace(0,m-1,8,device='cuda').long()
            ni=torch.linspace(0,n-1,8,device='cuda').long()
            def decode(t,indices):
                if t.dtype == torch.int8:
                    from deep_gemm.utils.math import cast_back_from_fp4
                    ones=torch.ones((len(indices),k//32),device='cuda')
                    return cast_back_from_fp4(t.index_select(0,indices),ones,32)
                return t.view(torch.uint8).index_select(0,indices).view(t.dtype).float()
            picked=decode(a[0],mi) @ decode(b[0][0],ni).T
            actual=ref.index_select(0,mi).index_select(1,ni).float()
            assert torch.isfinite(actual).all() and (actual-picked).norm()/picked.norm()<.02,(m,n,k,'reference')
            continue
        assert torch.equal(ref,y),(m,n,k,mode,'eager')
        g=torch.cuda.CUDAGraph()
        with torch.cuda.graph(g):call()
        graphs[mode]=g
        g.replay();torch.cuda.synchronize();assert torch.equal(y,ref)
    # Graph replays use the original input/output addresses. Keep their storage live.
    return graphs,(a,b,labels,y)

def bench(m,n,k,fp4=False,weight_fp4=False):
    graphs,storage=prepare(m,n,k,fp4,weight_fp4)
    iters=max(1,min(24,round(4e13/(2*m*n*k))))
    times=[]
    for rep in range(12):
        # Counterbalance which order is first in each consecutive pair of repetitions.
        seq=['row','column']
        if (rep%2)^random.Random(454+rep//2).randrange(2):seq.reverse()
        for mode in seq:
            g=graphs[mode];g.replay();torch.cuda.synchronize()
            start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(iters):g.replay()
            end.record();end.synchronize()
            times.append(dict(rep=rep,name=mode,ms=start.elapsed_time(end)/iters))
    tel={mode:measure(g,int(os.getenv("GPM_GPU", "0")),per_graph=1,samples=3) for mode,g in graphs.items()} if not (fp4 or weight_fp4) else {}
    with out.open('a') as f:print(json.dumps(dict(m=m,n=n,k=k,times=times,tele=tel,bitwise=True,
                l2_bytes=torch.cuda.get_device_properties(0).L2_cache_size,iters=iters)),file=f)
    print('verified',m,n,k,flush=True)

if __name__ == "__main__":
    # The first axis changes full weight bytes while keeping each 256-column group fixed.
    # The second grows the actual column group above physical L2 at fixed expert M and N.
    shapes=[(m,n,4096) for m in (8192,32768) for n in (4096,16384,32768,49152,65536,131072)]
    shapes += [(8192,4096,k) for k in (32768,131072,262144,524288,786432)]
    if os.environ.get('CROSSOVER_EXTEND'):
        shapes=[(32768,n,4096) for n in (4096,20480,24576,28672)]
        shapes += [(32768,4096,k) for k in (32768,131072,262144,524288,655360,786432)]
    done={(r['m'],r['n'],r['k']) for r in map(json.loads,out.read_text().splitlines())} if out.exists() else set()
    for shape in shapes:
        if shape not in done:
            bench(*shape)
            torch.cuda.empty_cache()
