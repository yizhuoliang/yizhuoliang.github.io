"""Run all shapes displayed in Figure 1, split across four independent GPUs."""
import os
import random
from itertools import product
import torch
from single import bench

precision = os.environ['QUANTIZATION']
if precision not in ('W4A8', 'W8A8'):
    raise ValueError(precision)
rows = [1024*i for i in (1,2,4,8,12,16,24,32,48,64)]
columns = [1024*i for i in (1,2,4,6,8,12,16,20,24,28,32)]
shapes = list(product(rows, columns, [2048,4096,8192]))
random.Random(888).shuffle(shapes)
for shape in shapes[int(os.environ['GPM_GPU'])::4]:
    bench(*shape, weight_fp4=precision=='W4A8')
    torch.cuda.empty_cache()
