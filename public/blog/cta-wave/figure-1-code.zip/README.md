# Figure 1 · GB300 W4A8 and W8A8 traversal benchmark

This archive contains the scheduler change, timing harness and measurement grid. Raw Data on the article page contains each of the 12 paired CUDA event timings per plotted shape, in milliseconds per projection.

Build vllm-project/DeepGEMM at 0820030756945b2daec208e8e8255268360f337d with schedule.patch applied (git apply). Install it in a compatible CUDA / PyTorch environment for SM103 with nvidia-ml-py available. The two modified schedules retain the stock two-CTA tile shape and compute pipeline.

For one shape with the patched extension installed, run from this directory on an allocated GB300:

    mkdir -p results
    CUDA_VISIBLE_DEVICES=0 GPM_GPU=0 OUT=results python -c 'from single import bench; bench(32768, 4096, 4096)'

Arguments are M, N, K. Pass weight_fp4=True to bench for MXFP4 weights and FP8 activations (W4A8). Both formats use one unit scale per 32 elements. Input generation and output validation run outside the timed region.

To measure every displayed shape, run grid.py with QUANTIZATION=W4A8 or W8A8. Set GPM_GPU=0 through 3 for four independent workers, CUDA_VISIBLE_DEVICES to each worker's GPU, and OUT to separate existing directories. single.jsonl records each pair of CUDA event timings. NVML samples for W8A8 are collected separately from timing. The plotted change is the median of 100*(column_ms/row_ms-1) across 12 paired repetitions.
