"""Integrate NVML GPM device-wide DRAM bandwidth over an exclusive GPU work window."""
import math, time, statistics
import torch
import torch.distributed as dist
import pynvml as nv

METRICS={10:'dram_bw_pct',5:'tensor_pct',164:'dram_cache_hit_pct',165:'dram_cache_miss_pct'}
def measure(graph,rank,per_graph=4,samples=3):
    nv.nvmlInit()
    h=nv.nvmlDeviceGetHandleByIndex(rank)
    a,b=(nv.nvmlGpmSampleAlloc() for _ in range(2))
    def window(first,last):
        req=nv.c_nvmlGpmMetricsGet_t()
        req.version=1;req.numMetrics=len(METRICS);req.sample1=first;req.sample2=last
        for i,k in enumerate(METRICS):req.metrics[i].metricId=k
        result=nv.nvmlGpmMetricsGet(req)
        return {key:float(x.value) if x.nvmlReturn==0 and math.isfinite(x.value) else None
                for key,x in zip(METRICS.values(),result.metrics)}
    start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
    graph.replay();start.record()
    for _ in range(8):graph.replay()
    end.record();end.synchronize()
    loops=min(100000,max(6,round(550/max(.002,start.elapsed_time(end)/8))))
    if dist.is_initialized():
        v=torch.tensor([loops],device='cuda')
        dist.broadcast(v,0)
        loops=int(v.item())
    data=[]
    for _ in range(samples):
        if dist.is_initialized():dist.barrier()
        torch.cuda.synchronize()
        nv.nvmlGpmSampleGet(h,a);t0=time.monotonic()
        for _ in range(loops):graph.replay()
        torch.cuda.synchronize()
        nv.nvmlGpmSampleGet(h,b);dt=time.monotonic()-t0
        sample=window(a,b)
        sample.update(seconds=dt,invocations=loops*per_graph)
        data.append(sample)
    for s in (a,b):nv.nvmlGpmSampleFree(s)
    nv.nvmlShutdown()
    return dict(samples=data)
